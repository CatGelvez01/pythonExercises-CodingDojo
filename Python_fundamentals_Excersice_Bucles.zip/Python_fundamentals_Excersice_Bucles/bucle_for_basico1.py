#Básico - Recorrido del 0 al 150
for i in range(0,151):
    print(i)

#Múltiplos de 5 - Números múltiplos 5 hasta el 1000
for i in range(5,1000,5):
    print(i)

#Contar de la manera del Dojo
for i in range(0,100):
    if (i%10==0):
        print("Coding")
    elif (i%5==0):
        print("Coding Dojo")
    else:
        print(i)

#Whoa es un gran idiota 
suma = 0

for i in range(0,500000,1):
    if (i%2!=0):
        suma=suma+i
print("Total:",suma)


#Cuenta regresiva 

for i in range(2018,-1,-4):
    print(i)

#Contador flexible

lowNum=4
highNum=8
mult=2
#No entendí




   


    




