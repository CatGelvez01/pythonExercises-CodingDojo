num1 = 42 #variable declaration/Data Types/Primitive/Number
num2 = 2.3 #variable declaration/Data Types/Primitive/Number
boolean = True #variable declaration/Data Types/Primitive/Boolean
string = 'Hello World' #variable declaration/Data Types/Primitive/String
pizza_toppings = ['Pepperoni', 'Sausage', 'Jalepenos', 'Cheese', 'Olives'] #Data Types/Composite/List/
person = {'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False} #Data Types/Composite/Dictionary/
fruit = ('blueberry', 'strawberry', 'banana') #Data Types/Composite/Tuples/
print(type(fruit)) #Data Types/Composite/Tuples/initialize
print(pizza_toppings[1]) #Data Types/Composite/List/access value
pizza_toppings.append('Mushrooms') #variable declaration/Data Types/Composite/List/add value
person['name'] = 'George' #Data Types/Composite/Dictionary/change value
person['eye_color'] = 'blue' #Data Types/Composite/Dictionary/add value
print(fruit[2]) #Data Types/Composite/Tuples/access value

if num1 > 45: #Conditional/if
    print("It's greater")
else:#Conditional/else
    print("It's lower")



if len(string) < 5:#Conditional/if
    print("It's a short word!")
elif len(string) > 15:#Conditional/else if
    print("It's a long word!")
else:#Conditional/else
    print("Just right!")

for x in range(5):#for loop/start
    print(x)
for x in range(2,5):#for loop/start
    print(x)
for x in range(2,10,3):#for loop/start
    print(x)
x = 0
while(x < 5):#while loop/increment
    print(x)
    x += 1

pizza_toppings.pop()#Data Types/Composite/List/delete value - index
pizza_toppings.pop(1)#Data Types/Composite/List/delete value

print(person)#Data Types/Composite/Dictionary/delete value - index
person.pop('eye_color')#Data Types/Composite/Dictionary/delete value - index
print(person)

for topping in pizza_toppings:#for loop/start
    if topping == 'Pepperoni':#Conditional/if
        continue
    print('After 1st if statement')
    if topping == 'Olives':#Conditional/if
        break#for loop/stop

def print_hello_ten_times():#Function/parameter
    for num in range(10):
        print('Hello')

print_hello_ten_times()

def print_hello_x_times(x):#Function/argument
    for num in range(x):
        print('Hello')

print_hello_x_times(4)

def print_hello_x_or_ten_times(x = 10):#Function/return
    for num in range(x):
        print('Hello')

print_hello_x_or_ten_times()#Function/return
print_hello_x_or_ten_times(4)#Function/return


"""
Bonus section
"""

# print(num3) - NameError: name <variable name> is not defined
# num3 = 72 - variable declaration/Data Types/Primitive/Number
# fruit[0] = 'cranberry' - TypeError: 'tuple' object does not support item assignment
# print(person['favorite_team']) - KeyError: 'favorite_team'
# print(pizza_toppings[7]) - IndexError: list index out of range
#   print(boolean) IndentationError: unexpected indent
# fruit.append('raspberry') -  AttributeError: 'tuple' object has no attribute 'append'
# fruit.pop(1) - AttributeError: 'tuple' object has no attribute 'pop'